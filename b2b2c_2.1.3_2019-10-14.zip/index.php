<?php
/** 
 * UQ云商：	www.uqcms.com  
 * 联系QQ：	2200631718 
 * 可免费商用，需要留UQ云商链接作为交换，只首页底部留取即可，不影响使用。
 */
  define('UQCMS', 'b2b2c'); define('UQCMS_PATH',dirname(__FILE__).'/'); $uq0 = 'data/install.lock'; if(!file_exists($uq0)){ header("Content-type: text/html; charset=utf-8"); header("Location:install.php"); exit('程序未安装，请<a href="install.php">点此安装</a> ，或者访问:http://域名/install.php 进行安装！'); } include_once UQCMS_PATH.'UQframework/core.class.php'; 