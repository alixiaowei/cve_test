// JavaScript Document 
$(function(){
		
	$("form").submit(function(){ 
		var error_state = 0;
		$("input").each(function(){
			$this = $(this);
			var ch_name = $this.attr('ck');
			//******ajax check--
			
			var ch_url = $this.attr('ajax_url'); 
			if(ch_url != undefined){ 
				var ajax_msg  = $this.attr('ajax_msg');
				ajax_msg = ajax_msg?ajax_msg:'纯在此值';
				
				var input_name = $this.attr('name');
				var input_val = $this.val(); 
				$.ajax({
					type:'post',
					url:ch_url,
					async:false,
					data:{input_name:input_val},
					success:function(data){  
						if(data == 1){ 
							
						}else if(data == 2){ 
							check_message(ajax_msg,$this);
							error_state = 1;
						}else{
							check_message(ajax_msg,$this);
							error_state = 1;
						} 
					} 
				});
			}
			
			//--------------- 
			var text_msg = $this.attr('ck_msg');
			var text_msg = (text_msg==undefined)?'':text_msg; 
			if(ch_name == "text"){  
				var min_size = $this.attr('ck_min');
				var max_size = $this.attr('ck_max');  
				if($this.val() == ''){  
					check_message(text_msg+'不能为空',$this);
					error_state = '1';
				}else{
					if(min_size != undefined){ 
						if(min_size > $this.val().length){
							check_message(text_msg+'不能小于'+min_size+'位',$this);
							error_state = '1';
						}
					}
					if(max_size != undefined){
						if(max_size < $this.val().length){
							check_message(text_msg+'不能大于'+max_size+'位',$this);
						 	error_state = '1';
						} 
					} 
				}
			} 
			if(ch_name == 'email'){
				if($this.val() == ''){ 
					check_message('邮件不能为空',$this);
					error_state = '1';
				}else if($this.val().match(/^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/)){
					check_message('邮件格式不正确',$this);
					error_state = '1';
				}
			}
			
			if(ch_name == 'mobile'){ 
				if($this.val() == ''){ 
					check_message('重复密码错误',$this);
					error_state = '1';
				}else if($this.val().match(/^(?:13\d|15\d|18\d)\d{5}(\d{3}|\*{3})$/)){
					check_message('手机格式不正确',$this);
					error_state = '1';
				}
			}
			
			if(ch_name == 'em'){
				if($this.val().match(/^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/)){ 
					
				}else if($this.val().match(/^(?:13\d|15\d|18\d)\d{5}(\d{3}|\*{3})$/)){ 
					
				}else{
					check_message(text_msg+'格式不正确',$this);
					error_state = '1';
				}
			}
			 
		}); 
		if(error_state == '1'){
			return false;
		}  			
	});
	function check_message(msg,input_postion){
		var x = $(input_postion).offset().top; 
		var y = $(input_postion).offset().left;
		alert(msg);
		//input_error_box = '<div class="uq_input_error">'+msg+'</div>';  
		//$(input_error_box).show().css({ position:"absolute", top:x+30, left:y});
		 
	}
		   
});
