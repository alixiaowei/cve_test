// 本系统由UQCMS.COM云商提供技术支持 
// PC端使用的地址效果
$(function(){ 
	// ----------- 后台地址 ----------  
	$.fn.area = function(options){
		var defaults = {
			'prov':'0',
			'city':'0',
			'dist':'0'
		};
		var settings = $.extend({}, defaults, options);
	  	var prov = [], city = [], dist = [];
		$.ajax({  
			type : "get",  
			url : URI+"ajax/get_area",   
			async : false,  
			dataType : 'json',
			success : function(data){ 
				prov = data.prov;
				city = data.city;
				dist = data.dist;
			}
		});
		
		// 系统后台用
		prov_html =  '<span class="area_name">选择省/选择市/选择县</span>';
		prov_html += '<div class="area_html">';
		prov_html += ' <ul><a href="javascript:;" class="area_name_0 ch" data-level="0">请选择</a></ul>'+
					 ' <div class="con"></div>';
		prov_html += '</div>';	
		prov_html += '<input type="hidden" name="prov" id="prov" value="'+settings.prov+'"/>'+
					 '<input type="hidden" name="city" id="city" value="'+settings.city+'"/>'+
					 '<input type="hidden" name="dist" id="dist" value="'+settings.dist+'"/>';
		$(this).html(prov_html); 
		
		var area_name = '';	
		prov_html = '<div class="conbox">';
		$.each(prov, function(k, v){
			if(settings.prov == k){
				prov_html += '<a href="javascript:;" data-id="'+k+'" class="ch">'+v+'</a>';
				area_name += '<a href="javascript:;" data-level="0">'+v+'</a>';
			}else{
				prov_html += '<a href="javascript:;" data-id="'+k+'">'+v+'</a>';
			} 
		});
		prov_html += '</div>';
		$(".area_html .con").html(prov_html);
		
		// 默认关闭 
		$(".area_box").mouseover(function(e){
	 		if($(".area_html").is(":hidden")){
				$(".area_html").show();
			}else{
				$(".area_html").hide();
			}
		}).mouseout(function(){
	 		$(".area_html").hide();
		});/*
		$(document).unbind('click').on('click', '.area_box span.area_name', function(){
			if($(".area_html").is(":hidden")){
				$(".area_html").show();
			}else{
				$(".area_html").hide();
			}
		});
		// 点击任意处消失
		$(document).on('click', 'body', function(e){
			event.stopPropagation();		//阻止事件冒泡 
			num = $(e.target).parents('.area_box').length; 
			if(num == 0){
				$(".area_html").hide();
			} 
		});*/
		// 点击内容操作
		$(document).on('click', '.area_html .con .conbox a',function(e){
			$this = $(this);
			id = $this.attr('data-id');
			name = $this.html(); 
			
			if(city[id] != undefined){
				// name
				$(".area_html ul a:eq(0)").html(name).after('<a href="javascript:;" class="ch" data-level="1">请选择</a>').next().siblings().removeClass('ch')
				$(".area_html ul a:eq(1)").nextAll().remove();
				// con
				html = '<div class="conbox">'; 
				$.each(city[id], function(k, v){
					html += '<a href="javascript:;" data-id="'+k+'">'+v+'</a>';
				});
				html += '</div>';
				
				$(".conbox:eq(0)").nextAll().remove(); 
				$(".conbox").after(html).next().siblings().hide(); 
				
				$("input[name=prov]").val(id);
				$("input[name=city]").val(''); 
				$("input[name=dist]").val(''); 
			}else if(dist[id]){ 
				// name
				$(".area_html ul a:eq(1)").html(name).after('<a href="javascript:;" class="ch" data-level="2">请选择</a>').next().siblings().removeClass('ch');
				$(".area_html ul a:eq(2)").nextAll().remove();
				// con
				html = '<div class="conbox">'; 
				$.each(dist[id], function(k, v){
					html += '<a href="javascript:;" data-id="'+k+'">'+v+'</a>';
				});
				html += '</div>';  
				$(".conbox:eq(1)").nextAll().remove(); 
				$(".conbox:last").after(html).next().siblings().hide();
				
				$("input[name=city]").val(id); 
				$("input[name=dist]").val('');
			}else{	// 执行显示操作
				$(".area_html ul a:eq(2)").html(name);
				
				$("input[name=dist]").val(id);
				html = '';
				$(".area_html ul a").each(function(i){
					html += $(this).html()+'/';  
				});
				html = html.substring(0, html.length-1);
				$(".area_name").html(html);
				$(".area_html").hide();   
			} 
			$this.addClass('ch').siblings().removeClass('ch');
		}); 
		// 点击标题
		$(document).on('click', '.area_html ul a',function(e){
			$this = $(this);
			// name
			$this.addClass("ch").siblings().removeClass("ch");
			// con
			level = $this.attr('data-level');
			$(".area_html .conbox:eq("+level+")").show().siblings().hide();
		});
		
		// 有内容的处理
		if(settings.city != '0' && settings.dist != '0'){ 
			if(city[settings.prov]){
				city_html = '<div class="conbox">'; 
				$.each(city[settings.prov], function(k, v){ 
					if(k == settings.city){
						city_html += '<a href="javascript:;" data-id="'+k+'" class="ch">'+v+'</a>'; 
						area_name += '<a href="javascript:;" data-level="1">'+v+'</a>';
					}else{
						city_html += '<a href="javascript:;" data-id="'+k+'">'+v+'</a>';
					}
				}); 
				city_html += '</div>'; 
				$(".conbox").after(city_html).next().siblings().hide(); 	
			}
			
			if(dist[settings.city]){ 
				dist_html = '<div class="conbox">'; 
				$.each(dist[settings.city], function(k, v){
					if(k == settings.dist){
						dist_html += '<a href="javascript:;" data-id="'+k+'" class="ch">'+v+'</a>';
						area_name += '<a href="javascript:;" class="ch" data-level="2">'+v+'</a>';
					}else{
						dist_html += '<a href="javascript:;" data-id="'+k+'">'+v+'</a>';
					}
				}); 
				dist_html += '</div>'; 
				$(".conbox:last").after(dist_html).next().siblings().hide(); 
			}
			if(area_name){
				$(".area_html ul").html(area_name);	
				// 显示出最后的词
				html = '';
				$(".area_html ul a").each(function(i){
					html += $(this).html()+'/';  
				});
				html = html.substring(0, html.length-1);
				$(".area_name").html(html);	
			}else{
				$(".area_name").html('选择省/选择市/选择县');	
			}
			
		} 
	}  	   
});
 