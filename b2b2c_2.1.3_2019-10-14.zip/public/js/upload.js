// 文件上传
function upload(path, infile, type){ 
	jQuery.getScript(PUBLIC+"plug/ajaxfileupload.js", function() {  
		$(document).on('change', '#'+infile, function(){ 
			var $this = $(this);  
			$.ajaxFileUpload({ 
				url:SELLER+'album/upload?path='+path+'&v='+new Date().getTime(),
				secureuri:false, 
				fileElementId:infile,
				dataType: 'text',	//text json
				success: function(result){
					var data = jQuery.parseJSON(result);
					if(data.error == '0'){
						if(type == '1'){
							
							
							
						}else{
							$("#"+id).parents(".upload_box").find("input[type='hidden']").val(data.name); 
							$("#"+id).parents(".upload_box").find(".img img").attr('src', data.url); 
							$("#"+id).parents(".upload_box").find(".upload_one").show();
							$("#"+id).parents(".upload_box").find(".upload_btn").hide();		
						}
					}else{
						$.alert(data.msg);
					}
				}
			});
		});	
	});
	
	$(document).on('click', '.upload_box a.imgdel', function(){ 
		$(".upload_btn").show();
		$(".upload_one").hide(); 
		$(this).next("input").val('');
	}); 
}
 