// 本系统由UQCMS.COM云商提供技术支持
// 菜单展示部分
$(function(){
	$(".allcats_show").hover(function(){
		$(".menu").show();
	},function(){
		$(".menu").hide();
	});	
	 
	$(".mleft dl").hover(function(){
		$(this).find("dt i").css({"background-position":"-18px 0"});
	},function(){
		$(this).find("dt i").css({"background-position":"0"}); 
	}); 
	// 刷新验证码  
	$('img#vcode').click(function(){
		freshVcode();
	}); 
	function freshVcode(){
		$("img#vcode").attr('src', URI+'ajax/vcode?v='+(new Date()).valueOf());
	}
}); 
var timeout;
$.extend({
    postPage:function(url, args, callback){ 
        var body = $(document.body), form = $("<form method='post'></form>"), input;
        form.attr({"action":url});
        $.each(args,function(key,value){
            input = $("<input type='hidden'>");
            input.attr({"name":key});
            input.val(value);
            form.append(input);
        }); 
        form.appendTo(document.body); 
		typeof(callback) === 'function'&&callback();
        form.submit();
        document.body.removeChild(form[0]);
    },
	includePath: '', 
	getCss:function(cssUrl){
		var link = document.createElement('link');
		link.type = 'text/css'; link.rel = 'stylesheet'; link.href = cssUrl;
		document.getElementsByTagName("head")[0].appendChild(link);	
	},
	alert:function(str, callback){
		var timeout;
		var com_con = '<div class="com_bg"></div><div class="alert_box"><span>'+str+'</span></div>';
		$("body").append(com_con);
		width = $(".alert_box").width();
		inH = $(window).height();
		newHeight = inH/2-300;
		newHeight = 50;
		$(".alert_box").css({"margin-right":"-"+width/2+"px", 'top':''+newHeight+'px'});
		
		$(document).on('click', '.alert_box', function(){
			clearTimeout(timeout);
			$(".com_bg").remove(); 
			$(".alert_box").remove(); 
			callback();
		});
		
		timeout = setTimeout(function(){
			$(".com_bg").remove(); 
			$(".alert_box").remove(); 
			callback();
		}, 1500); 
	},
	alertLoad:function(str){
		var timeout;
		var com_con = '<div class="com_bg"></div><div class="com_box"><span>'+str+'</span></div>';
		$("body").append(com_con);
		width = $(".com_box").width();
		inH = $(window).height();
		newHeight = inH/2-100;
		$(".com_box").css({"margin-right":"-"+width/2+"px"}).animate({top:"80px"}, 50); 
	},
	loading:function(callback){ 
		var com_con = '<div class="loading_box"><span><img src="'+PUBLIC+'images/loading.gif"></span></div>';
		$("body").append(com_con);
		width = $(".loading_box").width();
		inW = $(window).width();
		newWidth = (inW/2)-(width/2)
		inH = $(window).height();
		newTop = (inH/2)-110; 
		$(".loading_box").css({"left":newWidth, 'top':newTop+"px"}); 
	},
	loadingClose:function(){
		$(".loading_box").remove();
	}
});
 
function pr(obj){ 
	var description = ""; 
	for(var i in obj){ 
	var property=obj[i]; 
		description+=i+" = "+property+"\n"; 
	} 
	alert(description); 
} 
// 打印对象
function dump(arr,level) {
    var dumped_text = "";
    if(!level) level = 0;
     
    //The padding given at the beginning of the line.
    var level_padding = "";
    for(var j=0;j<level+1;j++) level_padding += "    ";
     
    if(typeof(arr) == 'object') { //Array/Hashes/Objects 
        for(var item in arr) {
            var value = arr[item];
             
            if(typeof(value) == 'object') { //If it is an array,
                dumped_text += level_padding + "'" + item + "' ...\n";
                dumped_text += dump(value,level+1);
            } else {
                dumped_text += level_padding + "'" + item + "' => \"" + value + "\"\n";
            }
        }
    } else { //Stings/Chars/Numbers etc.
        dumped_text = "===>"+arr+"<===("+typeof(arr)+")";
    }
    return dumped_text;
}

function GetQueryString(name){
     var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
     var r = window.location.search.substr(1).match(reg);
     if(r!=null)return  unescape(r[2]); return null;
} 
// 发送短信 
function send_sms(mobile, vcode, click_btn, ck_status){  
	$(click_btn).attr("disabled", true);
	//if(mobile.match(/^1(3|4|5|7|8|9)\d{9}$/)){ 
		ck_status = ck_status?ck_status:'0';
		$.ajax({
			type:'POST',
			url:URI+'member/get_sms_code',
			data:{mobile:mobile, vcode:vcode, ck_status:ck_status}, 
			success:function(result){ 
				var data = jQuery.parseJSON(result); 
				if(data.error == 0){
					RemainTime(click_btn);
				}else{ 
					$.alert(data.msg);
					$(click_btn).attr("disabled", false);
				}
			},
			error:function(){
				$.alert('系统繁忙');
			}
		}); 
	//}else{ 
	//	$.alert('手机格式不正确');
	//	$(click_btn).attr("disabled", false);
	//}
}
function decodeUnicode(str) { str = str.replace(/\\/g, "%"); return unescape(str);  } 
function decodeUnicode(str) { str = str.replace(/\\/g, "%"); return unescape(str);  }  
code = '\u672c\u7cfb\u7edf\u7531\u0055\u0051\u0043\u004d\u0053\u002e\u0043\u004f\u004d\u63d0\u4f9b\u6280\u672f\u652f\u6301';
console.log("%c "+decodeUnicode(code), "color:#f00; font-size:12px;");
var iTime = 59;
var Account;
function RemainTime(click_btn){ 
	$(click_btn).attr("disabled", true);
	var iSecond, sSecond="", sTime="";
	if(iTime >= 0){
		iSecond = parseInt(iTime%60);
		iMinute = parseInt(iTime/60)
		if(iSecond >= 0){
			if(iMinute>0){
				sSecond = iMinute + "分" + iSecond + "秒";
			}else{
				sSecond = iSecond + "秒";
			}
		}
		//请在51秒
		sTime='请在'+sSecond+'后重试';
		if(iTime==0){
			clearTimeout(Account);
			sTime='获取手机验证码';
			iTime = 59; 
			$(click_btn).attr("disabled", false);
		}else{
			Account = setTimeout(function(){
				RemainTime(click_btn);						  
			}, 1000);
			iTime=iTime-1;
		} 
	}else{
		sTime='没有倒计时';
	}
	$(click_btn).val(sTime); 
}

function countDown(cls_mk){
	$(cls_mk).html( '<span class="djs_day uq_color">0</span><i>&nbsp;</i>'+
					'<span class="djs_hour uq_color">00</span><i>:</i>'+
					'<span class="djs_minute uq_color">00</span><i>:</i>'+
					'<span class="djs_second uq_color">00</span>');
	var day_elem = $(cls_mk).find('.djs_day'); 
	var hour_elem = $(cls_mk).find('.djs_hour'); 
	var minute_elem = $(cls_mk).find('.djs_minute'); 
	var second_elem = $(cls_mk).find('.djs_second');
	//if(typeof end_time == "string") 
	//var end_time = new Date(time).getTime(),
	//sys_second = (end_time - new Date().getTime())/1000; 
	sys_second = $(cls_mk).attr('data-diff');
	if (sys_second > 1) { 
		sys_second -= 1;
		var day = Math.floor((sys_second / 3600) / 24); 
		var hour = Math.floor((sys_second / 3600) % 24); 
		var minute = Math.floor((sys_second / 60) % 60); 
		var second = Math.floor(sys_second % 60); 
		if(day == '0'){
			$(".djs_day").remove();	
		}else{
			day_elem && $(day_elem).text(day);						//计算天 
		}
		$(hour_elem).text(hour < 10 ? "0" + hour:hour);			//计算小时 
		$(minute_elem).text(minute < 10 ? "0" + minute:minute);	//计算分钟 
		$(second_elem).text(second < 10 ? "0" + second:second);	//计算秒杀 
	}else{
		clearInterval(timer); 
	}
	var timer = setInterval(function(){ 
		if (sys_second > 1) { 
			sys_second -= 1; 
			var day 	= Math.floor((sys_second / 3600) / 24); 
			var hour 	= Math.floor((sys_second / 3600) % 24); 
			var minute 	= Math.floor((sys_second / 60) % 60); 
			var second 	= Math.floor(sys_second % 60); 
			if(day == '0'){
				$(".djs_day").remove();	
			}else{
				$(day_elem).text(day);						//计算天 
			}
			$(hour_elem).text(hour < 10 ? "0" + hour:hour);			//计算小时 
			$(minute_elem).text(minute < 10 ? "0" + minute:minute);	//计算分钟 
			$(second_elem).text(second < 10 ? "0" + second:second);	//计算秒杀 
		}else{ 
			clearInterval(timer); 
		}
	}, 1000); 
}

function _delete(url, btn, callback)
{ 
	$("a.delete").click(function(){ 
		id = $(this).attr('data-id');
		if (!confirm("确认要删除？")) { 
			if(window.event){
				window.event.returnValue = false;
			}else{  
				event.preventDefault();	//for firefox
			}
		}else{
			$.post(url, {id:id}, function(result){ 
				data = jQuery.parseJSON(result); 
				if(data.error == '0'){
					$.alert('删除成功');  
					if(callback == undefined){
						location.reload();
					}else{
						callback();	
					}
				}else{
					$.alert(data.msg);	
				}
			}); 		
		} 
	});
}

// 图片懒加载
function lazyload(){
	jQuery.getScript(PUBLIC+'plug/jquery.lazyload.js', function(){
		$("img.lazy").show().lazyload({effect: "fadeIn", threshold:100, skip_invisible : false}); 							  
	});	
}
/*------------------------ 以下为弹窗部分 --------------------*/
function ajax_load_open(){
	conhtml = '<div class="dg_bgcolor" onclick="ajax_close();"></div>'+
			  '<div class="dg_box_bar"><div class="dg_box loading"><img src="'+PUBLIC+'images/loading.gif"></div></div>';
	$("body").after(conhtml);  
	$(".dg_box").css({"width":'50px', "height":"50px"});
}
function ajax_load_con(con, width, height){
	var width = width?width:'500'; 
	var height = height?height:'auto'; 
	//$(".dg_bgcolor").height(document.body.scrollHeight);
  	//$(".dg_bgcolor").width(document.body.scrollWidth); 
   	//$(".dg_bgcolor").fadeTo(200, 0.5);  
	$(".dg_box_bar").html(con).css({opacity:'0',marginTop:'-10px'}).animate({opacity:'1',marginTop:'0'},200); 
	$(".dg_box").css({"width":width,"height":height, "left": $(window).width()/2 - width/2, "top": $(window).height()/2 - height/2 - 50}).addClass('ch'); 
} 
function ajax_close(){
	$(".dg_box").addClass('rch');
	$(".dg_box_bar").animate({marginTop:'-10',opacity:'0'},300).delay(200).queue(function(){ $(this).remove(); }); 
	$(".dg_bgcolor").animate({opacity:'0'},300).delay(300).queue(function(){ $(this).remove(); }); 
} 
function ajax_dialog(name, url, width, height){
	ajax_load_open();
	$.get(url, function(data){
		var conbox = 
			'<div class="dg_box"><div class="dg_box_main">'+
				'<div class="name"><span>'+name+'</span><em onclick="ajax_close();">×</em></div>'+
				'<div class="con"><div class="mask_whit hide"></div>'+data+'</div>'+
				'<div class="foot"><a href="javascript:;" onclick="ajax_submit();" class="fsave">确定</a><a class="fcancel" href="javascript:;" onclick="ajax_close();">取消</a></div>'+
			'</div></div>'; 
		ajax_load_con(conbox, width, height);
	}); 
} 
function dialog(name, con, width, height){
	var width = width?width:'500'; 
	var height = height?height:'auto';
	$("body").after('<div class="dg_bgcolor"></div><div class="dg2_box_bar"></div>'); 
	var dialog_con_box = '<div class="dg2_box">'+
			'<div class="name"><span>'+name+'</span><em onclick="ajax_close();">×</em></div>'+
			'<div class="con" >'+con+'</div>'+
			'<div class="foot"><a class="fsave" href="javascript:;" onclick="dialog_submit();">确定</a>'+
			'<a class="fcancel" href="javascript:;" onclick="ajax_close();">取消</a></div>'+
		'</div>';  
	$(".dg_box_bar").html(dialog_con_box).css({opacity:'0',marginTop:'-10px'}).animate({opacity:'1',marginTop:'0'},200); 
	$(".dg_box").css({"width":width, "height":height}).addClass('ch'); 
}
/*-------------------------------------------------------*/
function change_vcode(){ 
	var src = URI+'ajax/vcode?t='+(new Date()).valueOf();
	$("#vcode_img").attr('src',src);
}  

// ajax登陆
function sys_login(callback){  
	width = '390'; 
	height = 'auto';
	ajax_load_open();
	$.ajaxSetup({cache:false});
	$.get(URI+'member/login_ajax', function(data){  
		conbox = '<div class="dg_box"><div class="dg_box_con" id="login_user_all">'+
					 '<div class="name" id="login_user"><span>用户登陆</span><em onclick="ajax_close();">×</em></div>'+
					 '<div class="con" >'+data+'</div>'+ 
				 '</div></div>'; 
		ajax_load_con(conbox, width, height);
	});  
	$(document).on('click', 'input#ajax_login', function(){
		var username = $('input[name=username]').val();
		var password = $('input[name=password]').val(); 
		var vcode = $('input[name=vcode]').val(); 
		if(username == ''){
			$("#error_msg").show().html('用户名不能为空'); return false;
		} 
		if(password == ''){
			$("#error_msg").show().html('密码不能为空'); return false;
		}
		$('.submit_login').attr("disabled", true).val('正在登陆..');
		$.ajax({
			type:'POST',
			url:URI+'member/login_do',
			data:{username:username, password:password, vcode:vcode}, 
			success:function(result){ 
				var data = jQuery.parseJSON(result); 
				if(data.error == '0'){
					$('.submit_login').attr("disabled", false).val('登陆');
					ajax_close();
					callback();
					return;
				}else{ 
					ckVcode();
					$("#error_msg").show().html(data.msg);
					$('.submit_login').attr("disabled", false).val('登陆');
					change_vcode(); 
				} 
			},
			error:function(){
				$.alert('错误', function(){
					$('.submit_login').attr("disabled", false).val('登陆');			   
				});
			}
		});
		return false; 
	}); 
	$("input[name='username'],input[name='password']").blur(function(){
		ckVcode();
	});
	function ckVcode(){
		var username = $("input[name='username']").val();
		$.post('<{$__URI__}>member/is_vcode',{username:username},function(result){
			data = jQuery.parseJSON(result); 
			if(data.error == '1'){
				$("#vcodebox").show();
			}else{
				$("#vcodebox").hide();
			}
		});
		return false;
	}
}
// 登出
function logout(){
	$.ajax({
		type:'GET',
		url:URI+'index/logout', 
		success:function(result){ 
			var data = jQuery.parseJSON(result); 
			if(data.error == '0'){
				location.href=URI+"index/login";
				return;
			}else{ 
				$.alert('退出失败');
			} 
		},
		error:function(){
			$.alert('执行退出错误'); 
		}
	});	
}

$(function(){ 
	$("form#form").submit(function(){ 
		$this = $(this);
		var post_url = $this.attr('action'); 
		var post_method = $this.attr('method'); 
		if(post_method == 'post'){
			var status = $this.attr('status'); 
			var back_status = $this.attr('back'); 
			$.ajax({
				type:'POST',
				url:post_url,
				data:$this.serialize(), 
				success:function(result){  
					if(status != undefined){ 
						$.alert(result); 
					}
					data = $.parseJSON(result);
					if(data.error == 0){
						$.alert('保存成功',function(){
							if((back_status != undefined) || (back_status == '')){
								$('html,body').animate({scrollTop:0}, 'fast');
							}else{ 
								window.history.back(); 
							}						
						});
						if((back_status != undefined) || (back_status == '')){
							$('html,body').animate({scrollTop:0}, 'fast');
						}
					}else{ 
						$.alert(data.msg);
						$("input[name='"+data.name+"']").addClass('error');
					}
				},error:function(){
					$.alert('系统繁忙');
				}
			}); 
			return false;	
		}
	}); 
});
 