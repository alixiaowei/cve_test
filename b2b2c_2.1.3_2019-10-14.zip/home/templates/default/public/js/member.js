// JavaScript Document
$(function(){
	// 保存
	$("form#form").submit(function(){ 
		$this = $(this);
		var post_url = $this.attr('action'); 
		var post_method = $this.attr('method'); 
		if(post_method == 'post'){
			var status = $this.attr('status'); 
			var back_status = $this.attr('back'); 
			$.ajax({
				type:'POST',
				url:post_url,
				data:$this.serialize(), 
				success:function(result){
					if(status != undefined){ 
						$.alert(result); 
					}
					data = $.parseJSON(result);
					if(data.error == 0){ 
						$.alert('保存成功'); 
					/*
						$.alert('保存成功',function(){
							if((back_status != undefined) || (back_status == '')){
								$('html,body').animate({scrollTop:0}, 'fast');
							}else{ 
								window.history.back(); 
							}						
						});
						if((back_status != undefined) || (back_status == '')){
							$('html,body').animate({scrollTop:0}, 'fast');
						}
						*/
					}else{ 
						$.alert(data.msg);
						//$.alert(data.msg);
						//$("input[name='"+data.name+"']").addClass('error');
					}
				},error:function(){
					 alert('系统繁忙');
				}
			}); 
			return false;	
		}
	});	   
});
