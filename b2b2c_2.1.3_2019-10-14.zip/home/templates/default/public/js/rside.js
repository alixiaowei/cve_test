$(function(){
	rside_html = '<div class="rside" id="rside">'+
			'<div class="rside_menu">'+
			'	<div class="rmctr">'+
			'		<div class="rmcart">'+
			'			<i></i>'+
			'			<p>购物车</p>'+
			'			<span>0</span>'+
			'		</div> '+
			'		<div class="rm_icon" id="rs_collect"><span>&nbsp;</span></div>'+
			'		<div class="rm_icon" id="rs_history"><span>&nbsp;</span></div>'+
			'	</div>'+
			'	<div class="rtop">'+
			'		<a href="javascript:;">顶部</a>'+
			'	</div>'+
			'</div>'+
			'<div class="rside_con">'+
			'	<div class="rs_con rs_cart"></div>'+
			'	<div class="rs_con rs_collect"></div>'+
			'	<div class="rs_con rs_history"></div>'+
			'</div> '+
		'</div> ';
	$(".bottom_bar").append(rside_html); 
	$(".rtop a").click(function(){
		var sc=$(window).scrollTop();
		$('body,html').animate({scrollTop:0}, 100);
	});
	$(window).scroll(function(){
		var sc = $(window).scrollTop();
		var rwidth = $(window).width()
		if(sc > 0){
			$("#rtop").css("display","block");
			$("#rtop").css("left",(rwidth-36)+"px")
		}else{
			$("#rtop").css("display","none");
		}
	});
	$(document).on("click", function(e){ 
		var target = $(e.target);
		if(target.closest("#rside").length == 0){ 
		 	rs_close();
		}
	}); 
	$(document).on("click", ".rs_close", function(){
		rs_close();
	}); 
	rs_open = function(){ 
		$(".rside").animate({right:'-15px'}, 100);
	}
	rs_close = function(){
		$(".rside").animate({right:'-285px'}, 100);
	} 
	$(document).on("click",".rmcart",function(){
		$.ajax({
			type:'GET',
			url:URI+'cart/small_list', 
			success:function(result){ 
				html = '<div class="rs_cname"><i></i><span>购物车</span><a href="javascript:;" class="rs_close">×</a></div>';
				var data = jQuery.parseJSON(result);
				rs_open();
				if(data.error == '1'){ 
					html += '<div class="rs_msg"><span>购物车还没有商品，赶快选购！</span></div>';
				}else{
					rs_open();
					html += '<div class="rs_ccon">';
					$.each(data.list, function(idx, obj){
						html += '<div class="cbox scbox_'+obj.id+'">';
						html += '<div class="img"><a href="index.php?m=goods&a=detail&id='+obj.gid+'"><img src="'+IMG_HOST+obj.images+'" width="60"></a></div>';
						html += '<div class="con"><div class="ttl"><a href="index.php?m=goods&a=detail&id='+obj.gid+'" target="_blank">'+obj.title+'</a></div>';
						html += '<div class="num"><span>￥'+obj.price+'X'+obj.buy_num+'</span><a href="javascript:;" class="rs_cdel" data-id="'+obj.id+'">删除</a></div>';
						html += '</div></div>';
					});
					html += '<div class="rs_cbuy"><a href="index.php?m=cart">去购物车结算</a></div>'; 
					html += '</div>';
				} 
				$('.rside_con .rs_collect').html(html).show().siblings().hide(); 
			},error:function(){
				alert('系统繁忙');
			}
		});
	});
	// 删除
	$(document).on("click", ".rs_cdel", function(event){ 
		var $this = $(this);
		cartid = $(this).attr('data-id'); 
		$.ajax({
			type:'post',
			data:{cartid:cartid},
			url:URI+'cart/del', 
			success:function(result){
				data = jQuery.parseJSON(result); 
				if(data.error == '0'){
					$(".scbox_"+cartid).remove();
					event.stopPropagation();	// 删除之后不触发其他时间
				}else{
					alert('删除失败');	
				}
			},error:function(){
				alert('系统繁忙');
			}
		});  
	});
	$(document).on("click","#rs_collect",function(){
		rs_collect_func();
	});
	function rs_collect_func(){
		$.ajax({
			type:'GET',
			url:URI+'ajax/info?page=1', 
			success:function(result){
				html = '<div class="rs_cname"><i></i><span>我的收藏</span><a href="javascript:;" class="rs_close">×</a></div>';
				var data = jQuery.parseJSON(result); 
				if(data.islogin != '0'){
					if(data.error == '1'){
						html += '<div class="rs_msg"><span>还没有浏览历史哦~~</span></div>';
					}else{ 
						html += '<div class="rs_ccon">';
						$.each(data.list, function(idx, obj){
							html += '<div class="cgs">';
							html += '<div class="img"><a href="index.php?m=goods&a=detail&id='+obj.gid+'" target="_blank"><img src="'+IMG_HOST+obj.images+'" width="60"></a></div>';  
							html += '<div class="num"><span>￥'+obj.price+'</span> </div>';
							html += '</div>';
						});
						html += '</div>'; 
						
					} 
					$('.rside_con .rs_history').html(html).show().siblings().hide(); 
					rs_open(); 
				}else{ 
					sys_login(function(){
						rs_collect_func();
						ajax_close();
					}); 
				}
			},error:function(){
				alert('系统繁忙');
			}
		});
	}
	
	$(document).on("click","#rs_history",function(){
		rs_history_func();
	});
	function rs_history_func(){
		$.ajax({
			type:'GET',
			url:URI+'ajax/goods_histroy', 
			success:function(result){ 
				html = '<div class="rs_cname"><i></i><span>浏览记录</span><a href="javascript:;" class="rs_close">×</a></div>';
				var data = jQuery.parseJSON(result); 
				if(data.islogin != '0'){
					if(data.error == '1'){
						html += '<div class="rs_msg"><span>还没有浏览历史哦~~</span></div>';
					}else{ 
						html += '<div class="rs_ccon">';
						$.each(data.list, function(idx, obj){
							html += '<div class="cbox">';
							html += '<div class="img"><a href="index.php?m=goods&a=detail&id='+obj.id+'" target="_blank"><img src="'+IMG_HOST+obj.images+'" width="60"></a></div>';
							html += '<div class="con"><div class="ttl"><a href="index.php?m=goods&a=detail&id='+obj.id+'" target="_blank">'+obj.title+'</a></div>';
							html += '<div class="num"><span>￥'+obj.price+'</span> </div>';
							html += '</div></div>';
						});
						html += '</div>'; 
					}

					$('.rside_con .rs_history').html(html).show().siblings().hide(); 
					rs_open();
				}else{
					sys_login(function(){
						rs_history_func();
						ajax_close();
					});
				}
			},error:function(){
				alert('系统繁忙');
			}
		});	
	}
		
});


 