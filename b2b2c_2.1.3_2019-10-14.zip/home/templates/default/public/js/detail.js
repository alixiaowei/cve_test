// JavaScript Document 
$(document).on('click',"#plus_button",function(){  
	buy_num = $("#buy_num").val(); 
	stock = $("#stock").val(); 
	buy_value = parseInt(buy_num)+parseInt('1');
	if(buy_value < stock){
		limit_num = $("#limit_num").val();
		if(limit_num != 0){
			if(limit_num < buy_value){
				$.alert('每次限购'+limit_num+'个'); return false;
			}
		} 
		$("#buy_num").val(buy_value); return false; 
	}else{
		$.alert('库存不足');	 
	}
});

$(document).on('click',"#minus_button",function(){  
	var now_num = $("#buy_num").val();
	var num = parseInt(now_num)-parseInt('1');
	if(num <= 0){
		$.alert('最少为一个数量'); 
		return false;
	}
	$("#buy_num").val(num); 
});

// 店铺收藏 
$(document).on('click', '.collect_shop', function(){ 
	$this = $(this); 
	spid = $('#shop_id').val();
	$.post(URI+"ajax/collect_shop",{spid:spid}, function(result){ 
		var data = jQuery.parseJSON(result);  
		if(data.error == '0'){
			if(data.status == '1'){ 
				$this.html('已经收藏');
			}else if(data.status == '0'){
				$this.html('店铺收藏');
			}
		}else if(data.error == '4'){
			sys_login();
		}else{
			alert(data.msg);
		} 
	});
});
// 产品收藏 
$(document).on('click', '.collect_goods', function(){ 
	$this = $(this);
	gid = $("#goods_id").val();
	$.post(URI+"ajax/collect_goods",{gid:gid},function(result){ 
		var data = jQuery.parseJSON(result);  
		if(data.error == '0'){
			if(data.status == '1'){ 
				$this.html('已经收藏');
			}else if(data.status == '0'){
				$this.html('收藏产品');
			}
		}else if(data.error == '4'){
			sys_login();
		}else{
			alert(data.msg);
		} 
	});
});

// 优惠券领取 
$(document).on('click', 'a.coupon_receive', function(){ 
	id = $(this).attr('data-id');
	$.post(URI+'ajax/coupon_receive',{id:id},function(result){
		data = jQuery.parseJSON(result);
		if(data.error == '0'){
			$.alert('领取成功');
		}else if(data.error == '4'){
			sys_login(function(){
				$.post(URI+'ajax/coupon_receive',{id:id},function(result2){
					data1 = jQuery.parseJSON(result2);
					if(data1.error == '0'){
						$.alert('领取成功');
					}else{
						$.alert(data.msg);
					}
				});
			});
		}else{
			$.alert(data.msg);
		}
	});
});

$(function(){ 
	$(".wapbuycode").hover(function(){
		$('span',this).show();
	},function(){
		$('span',this).hide();
	});
	
	$(".simg a").mouseover(function(){
		$this = $(this);
		var bimg = $('img ',$this).attr('data-img');
		$(".bimg img").attr('src',bimg); 
		var bgimg = $('img ',$this).attr('data-big');
		$(".bimg img").attr('jqimg',bgimg); 
	});
	
 	$(".sku_box dl dd a").click(function(){ 
		$this = $(this); 
		var sku_img = $this.find('img').attr('data-img');
		if(sku_img != 'undefined'){
			$(".bimg img").attr('src',sku_img); 
			 var bgimg = $('img ',$this).attr('data-big');
			$(".bimg img").attr('jqimg',bgimg); 
		} 
	}); 
	
	// 切换部分
	$(".desc_name a").click(function(){
		$this = $(this);
		doid = $this.attr('doid');
		$this.addClass("ch").siblings().removeClass('ch'); 
		if(doid == 0){
			$(".desc_content").show();
			$(".desc_content").eq(2).hide(); 
		}else{ 
			$(".desc_content").hide();
			$(".desc_content").eq(doid).show();
		} 
	});
	
});

function get_cmt(url){
	$.get(url, function(result_html){ 
		$(".comment_box_html").html(result_html); 
	}); 
}

// 分页操作
$(document).on('click', ".comment_box_html .page a", function(event){ 
	jump_url = $(this).attr('href');
	if(jump_url){
		get_cmt(jump_url);
	} 
	if(window.event){
		window.event.returnValue = false;
	}else{  
		event.preventDefault();	 //for firefox
	}
}); 

// 加
$(document).on('click', "#num_plus", function(){
	buy_num = $("#buy_num").val(); 
	stock = $("#stock").val(); 
	buy_value = parseInt(buy_num)+parseInt('1');
	if(buy_value < stock){
		limit_num = $("#limit_num").val();
		if(limit_num != 0){
			if(limit_num < buy_value){
				alert('限购'+limit_num+'个'); return false;
			}
		} 
		$("#buy_num").val(buy_value); return false; 
	}else{
		alert('库存不足');	 
	}
});

// 减
$(document).on("click", "#num_minus", function(){  
	buy_num = $("#buy_num").val();
	limit_num = $("#limit_num").val();
	stock = $("#stock").val(); 
	num = parseInt(buy_num)-parseInt('1');
	if(num <= 0){
		alert('最少为一个数量'); 	
		return false;
	}else{
		$("#buy_num").val(num); 
	} 
}); 