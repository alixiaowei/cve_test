$(function(){
	$.extend({
		includePath: '', 
		getCss:function(cssUrl){
			var link = document.createElement('link');
			link.type = 'text/css'; link.rel = 'stylesheet'; link.href = cssUrl;
			document.getElementsByTagName("head")[0].appendChild(link);	
		},
		alert:function(str, callback){
			var timeout;
			var com_con = '<div class="com_bg"></div><div class="com_box"><span>'+str+'</span></div>';
			$("body").append(com_con);
			width = $(".com_box").width();
			inH = $(window).height();
			newHeight = inH/2-100;
			$(".com_box").css({"margin-right":"-"+width/2+"px", 'top':''+newHeight+'px'});
			
			timeout = setTimeout(function(){
				$(".com_bg").remove(); 
				$(".com_box").hide(1000).remove(); 
				callback();
			},1500); 
			$(document).on('click', '.com_box', function(){
				$(".com_bg").remove(); 
				$(".com_box").hide(1000).remove(); 
				clearTimeout(timeout);
				callback();
			});
		}
	}); 
	// 保存
	$("form#form").submit(function(){ 
		$this = $(this);
		var post_url = $this.attr('action'); 
		var post_method = $this.attr('method'); 
		if(post_method == 'post'){
			var status = $this.attr('status'); 
			var back_status = $this.attr('back'); 
			$.ajax({
				type:'POST',
				url:post_url,
				data:$this.serialize(), 
				success:function(result){  
					if(status != undefined){ 
						$.alert(result); 
					}
					data = $.parseJSON(result);
					if(data.error == 0){
						$.alert('保存成功',function(){
							if((back_status != undefined) || (back_status == '')){
								$('html,body').animate({scrollTop:0}, 'fast');
							}else{ 
								window.history.back(); 
							}						
						});
						if((back_status != undefined) || (back_status == '')){
							$('html,body').animate({scrollTop:0}, 'fast');
						}
					}else{ 
						$.alert(data.msg);
						$("input[name='"+data.name+"']").addClass('error');
					}
				},error:function(){
					$.alert('系统繁忙');
				}
			}); 
			return false;	
		}
	});
			   
});


