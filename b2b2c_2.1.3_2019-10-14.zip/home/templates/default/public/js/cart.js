$(function(){ 
	$('.small_cart').mouseenter(function(){
		$('.small_cart_list').html('<img src="'+PUBLIC+'images/loading.gif">');
		setTimeout(function(){ 
			small_cart_list();  							 
		},100);
		$(this).unbind('mouseenter');
	});
	
	function small_cart_list(){ 
		$.ajax({
			type:'GET',
			url:URI+'cart/small_list',
			success:function(result){ 
				data = jQuery.parseJSON(result);
				html = '';
				if(data.error == '0'){ 
					html += '<span class="ctname">最近新加商品</span>';
					html += '<div class="cldtl">';
					$.each(data.list, function(idx, obj){ 
						html += '<div class="clbox" id="scbox_'+obj.id+'">';
						html += '<div class="img"><a href="'+URI+'goods/'+obj.gid+HTML+'"><img src="'+IMG_HOST+obj.images+'"></a></div>';
						html += '<div class="ttl"><a href="'+URI+'goods/'+obj.gid+HTML+'">'+obj.title+'</a></div>';
						html += '<div class="num"><span>￥'+obj.price+'X'+obj.buy_num+'</span><a href="javascript:;" class="small_cart_del" data-id="'+obj.id+'">删除</a></div>';
						html += '</div>';
					});
					html += '</div>';
					html += '<div class="enterCart"><span>共'+data.total_num+'件商品，共计￥'+data.total_price+'</span><a href="'+URI+'cart/index">去购物车</a></div>';
				}else{ 
					html += '<div class="cartNull"><i></i><span>购物车还没有商品，赶快选购！</span></div>';
				}
				$(".small_cart_list").html(html); 
			},error:function(){
				alert('系统繁忙');
			}
		});  
	}
	
	scart_num();
	function scart_num(){
		$.get(URI+'cart/num',function(result){
			data = jQuery.parseJSON(result);
			if(data.error == '0'){
				$("#cart_num").html(data.num);
				$(".rmcart span").html(data.num);	
			} 
		});
	}
	
	$(document).on("click", 'a.small_cart_del',function(){
		$this = $(this);
		cartid = $this.attr('data-id');
		$.post(URI+"cart/del", {cartid:cartid}, function(result){ 
				data = jQuery.parseJSON(result); 
				if(data.error == '0'){ 
					small_cart_list();
				}else{
					alert('删除失败');	
				}			  
		});
	});
	
	// 购买点击
	$(document).on("click", '.nowbuy', function(e){  
		if($("a").hasClass('yyue')){
			var shop_id = $('#shop_id').val(); 
			var sku_id 	= $('#sku_id').val(); 
			var buy_num = $("#buy_num").val();
			var type = $(this).attr('data-type');
			if(type == '1'){		// 直接购买到结算页面  
				if(sku_id == '' || sku_id == 'undefind'){
					sku_error(); 
				}else{
					$.ajax({
						type:'post',
						url :URI+'ajax/check_login', 
						async:false,
						success:function(result){
							data = jQuery.parseJSON(result); 
							if(data.error == '0'){ 
								$.post(URI+'cart/create_settle', {post_method:'direct', sku_id:sku_id, buy_num:buy_num}, function(result){ 
									data = jQuery.parseJSON(result);
									if(data.error == '0'){
										location.href=URI+"cart/settle";
									}else{
										$.alert('创建交易失败');	
									}
								}); 
							}else if(data.error == '4'){
								sys_login(function(){ 
									$.post(URI+'cart/create_settle', {post_method:'direct', sku_id:sku_id, buy_num:buy_num}, function(result){ 
										data = jQuery.parseJSON(result);
										if(data.error == '0'){
											location.href=URI+"cart/settle";
										}else{
											$.alert('创建交易失败');	
										}
									}); 
								}); 
							}else{
								alert(data.msg);	
							}
						} 
					}); 
				} 
			}else if(type == '0'){	// 直接加入购物车
				var gid = $("#goods_id").val();  
				$.ajax({
					type:'post',
					data:{gid:gid, sku_id:sku_id, shop_id:shop_id, buy_num:buy_num},
					url:URI+'cart/add', 
					success:function(result){
						data = jQuery.parseJSON(result);  
						if(data.error == '0'){ 
							scart_num();
							sku_error_close();
							pay_status_box(data.cart_id); 
						}else if(data.error == '2'){ 
							sku_error();
						}else{
							showmsg(data.msg);	
						}
					},error:function(){
						alert('系统繁忙');
					}
				});
			} 
		}else{
			e.preventDefault(); 
		} 
	});
	
	function pay_status_box(cart_id){
		dialog_box = '<div class="buy_tip">' +
							'<div class="buy_tip_name"><p>宝贝已成功添加到购物车</p></div>'+
							'<div class="buy_tip_action"><a href="'+URI+'cart?cartid='+cart_id+'">去付款</a>'+
							'<a href="javascript::" class="close_dg2">继续购物</a></div>'+
						'</div>';
		var w = document.documentElement.clientWidth || document.body.clientWidth;
		var h = document.documentElement.clientHeight || document.body.clientHeight;
		$("body").after(dialog_box);
		width = $(".buy_tip").width();
		height = $(".buy_tip").height();
		left2 = w/2 - width/2;
		top2 = h/2-height/2-50;  
		$(".buy_tip").css({left:left2, top:top2, opacity:'0', marginTop:'200px'}).animate({opacity:'1',marginTop:'0'},100); 
	}
	
	$(document).on("click", 'a.close_dg2', function(){
	 	 $(".buy_tip").remove();
	});
	
	// 购物车移除
	$(document).on('click', ".cart_del", function(){
		var cartid = $(this).attr('cartid'); 
		$.ajax({  
			type:'post',
			data:{cartid:cartid},
			url:URI+'cart/del', 
			success:function(result){ 
				data = jQuery.parseJSON(result);  
				if(data.error == '0'){ 
					$(".cart_detail_"+cartid).remove();
					total_price();
					total = $(".gsbox").length;
					if(total == 0){
						location.reload();
					}
				}else{
					alert(data.msg);
				}
			},error:function(){
				alert('系统繁忙');
			}
		});
	});
	total_price();
	
	/* 购物车产品选中选择 */
	$(".ckbox_cartid").change(function(){
		total_price();
	}); 
}); 

// SKU ERROR
function sku_error(){
	if($(".sku_error").length == 0){
		$(".sku_box").append('<div class="sku_error">没有选择产品规格 </div><div class="sku_error_close" onclick="sku_error_close()">×</div>');
		$(".sku_box").addClass('error');
	}
	$(".sku_status").addClass('on').css({"padding-top":"10px","top":"10px","postion":"absolute"});
}

function sku_error_close(){ 
	$(".sku_box").removeClass('error');
	$(".sku_error,.sku_error_close").remove();
}

$(document).on('click', ".cart_plus", function(){
	$this = $(this);
	stock = $this.attr('data-stock');
	cartid = $this.attr('cartid');
	now_num = $("#cart_num_"+cartid).val();
	num = parseInt(now_num)+parseInt('1');
	if(num < stock){
		limit_num = $this.attr('data-buy-limit');
		if(limit_num != 0){
			if(num > limit_num){ 
				 return false;	
			}
		}
		$("#cart_num_"+cartid).val(num); 
		cart_num(cartid, num); 
	} 
	total_price();
});

$(document).on('click',".cart_minus",function(){ 
	$this = $(this);
	var cartid = $this.attr('cartid');
	var now_num = $("#cart_num_"+cartid).val();
	var num = parseInt(now_num)-parseInt('1');
	if(num > '0'){
		$("#cart_num_"+cartid).val(num);
		cart_num(cartid, num);
	} 
	total_price(); 
});

// 输入改变
$(document).on('blur', '.num', function(){
	var $this = $(this);
	var total = $this.val();
	if(total >= 1){
		var num = total;
	}else{
		var num = 1;
	}
	$this.val(num);
	var cartid = $(this).attr('cartid');
	cart_num(cartid, num);
	total_price(); 
}); 

function cart_num(cartid, num){
	$.post(URI+'cart/edit_num',{cartid:cartid, num:num}, function(result){
		 											
	}); 
}

function total_price(){ 
	var total_price = 0;
	var total_num = 0;
	var chk_num = 0;
	$(".cart_list .gsbox").each(function(){
		$this = $(this);
		var num = $(".cart_num_box input",this).val();
		var now_price = $(".cart_price span",this).html(); 
		var goods_price = parseInt(num) * parseFloat(now_price);
		$(".cart_total_price span",$(this)).html(goods_price.toFixed(2)); 
		
		if($("input[name='cartid[]']",$this).is(':checked')){
			total_price += parseInt(num) * parseFloat(now_price); 
			total_num += parseInt(num);
			chk_num += 1;
		}
	});
	if(chk_num <=0){
		$(".gopay").attr('disabled',true);
	}else{
		$(".gopay").attr('disabled',false);
	}
	$("#total_num span").html(total_num); 
	$("#total_price span").html(total_price.toFixed(2)); 
}   

/* 全选操作 */ 
$(function(){ 
	// 全部选择
	$(document).on('click', '.checked_cartid_all', function(){
		if(this.checked){
			$(".checked_cartid:checkbox,.checked_cartid_shop").attr("checked", true);  
			$(".checked_cartid_all").attr('checked', true); 
		}else{    
			$(".checked_cartid:checkbox,.checked_cartid_shop").attr("checked", false); 
			$(".checked_cartid_all").attr('checked', false);  
		}
		total_price();
	});
	// 店铺选择
	$(document).on('click', '.checked_cartid_shop', function(){
		$this = $(this);
		if(this.checked){
			$this.parents(".spbox").find(".gsbox .checked_cartid:checkbox").attr("checked", true); 
		}else{    
			$this.parents(".spbox").find(".gsbox .checked_cartid:checkbox").attr("checked", false); 
		}
		cart_check_sp(); 
		total_price();
	});
	// 产品选择
	$(document).on('click', 'input.checked_cartid', function(){
		$this = $(this).parents(".spbox");
		var num = 0;
		var loop = 0;
		$this.find("input.checked_cartid").each(function(){
			if($(this).attr("checked")){
				num++;
			}
			loop++;
		}); 
		if(num == loop){ 
			$this.find(".checked_cartid_shop").attr("checked", true);
		}else{
			$this.find(".checked_cartid_shop").attr("checked", false);
		} 
		cart_check_sp(); 
		total_price();
	});
	
	// 店铺选中情况 
	function cart_check_sp(){
		var spnum = 0;
		var sploop = 0; 
		$("input.checked_cartid_shop").each(function(){
			if($(this).attr("checked")){
				spnum++;
			}
			sploop++;
		}); 		
		if(spnum == sploop){ 
			$(".checked_cartid_all").attr("checked", true);
		}else{
			$(".checked_cartid_all").attr("checked", false);
		} 
	}

});