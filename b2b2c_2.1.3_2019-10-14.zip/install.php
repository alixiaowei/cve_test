<?php
/** 
 * UQ云商：	www.uqcms.com  
 * 联系QQ：	2200631718 
 * 可免费商用，需要留UQ云商链接作为交换，只首页底部留取即可，不影响使用。
 */
  header("Content-type: text/html; charset=utf-8"); if(version_compare(PHP_VERSION, '7.0.0', '<')){ exit('安装错误：当前版本为: '.phpversion().'。UQ云商系统需要支持PHP7.0以上的版本！'); } $uq0 = isset($_GET['step'])?$_GET['step']:'1'; $uq1 = 'data/install.lock'; if(file_exists($uq1)){ if($uq0 != '5'){ } } $uq2 = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; $uq3 = dirname($uq2); $uq4 = 'data/dbconfig.php'; $uq5 = 'data/web_secrit.php'; ?>
<!DOCTYPE html>
<html>
<head>
<title>UQCMS云商-系统安装</title>
<link rel="stylesheet" type="text/css" href="public/css/common_uqcms.css">
<script type="text/javascript" src="public/js/jquery.min.js"></script>
<script type="text/javascript" src="public/plug/jquery.nicescroll.js"></script>
<style type="text/css"> 
body{ background:#0972A3; min-width:1000px; min-height:700px; }
.main_bar{ width:100%; padding:10px 0; float:left; } 
.main_bar span{ padding:0 0 0 10px; float:left; }

.main{ width:800px; margin:0 auto; }
.maincon{ width:100%; background:#F3FBFE; margin:0 0 20px 0; float:left; } 
.head{ width:100%; background:#30ACE6; color:#fff; background: linear-gradient(to top right,#2C9ED3, #35B6F3, #35B6F3); border-bottom:1px solid #efefef; padding:15px 0 13px; float:left; } 
.head .lname{ font-size:22px; margin:7px 0 0 20px; padding:0 0 5px 35px; font-weight:bold; float:left; }
.head .rhelp a{ text-decoration:none; color:#fff; font-size:12px; margin:13px 65px 0 0; float:right; }
.head .rhelp a i{ background:#fff; width:15px; height:15px; color:#30ACE6; text-align:center; line-height:15px; border-radius:15px; margin:2px 5px 0 0; float: left; }

.navigation{ width:80%; padding:20px 10% 10px; float: left; }
.navigation span{ width:25%; float:left; }
.navigation span i{ width:30px; height:30px; text-align:center; line-height:30px; font-size:20px; background:#ddd; border-radius:30px; color:#999; font-family: "宋体"; float:left; } 
.navigation span.ch i{ width:30px; height:30px; background:#30ACE6; color:#fff; float:left; } 
.navigation span.ch{ color:#39f; }
.navigation span em{ font-size:14px; font-style:inherit; padding:5px 0 0 10px; float:left; } 

input[type="text"]{ border:1px solid #ddd; padding:6px; border-radius:2px; }
input[type="password"]{ border:1px solid #ddd; padding:6px; border-radius:2px; } 

table.ltable{ padding-bottom:10px; margin-bottom:20px; }
table.ltable thead tr th{ text-align:left; background:#E4F8FF; padding:5px 0 2px 10px; color:#078DBF; border:1px solid #E4F8FF;  }
table.ltable tbody tr td{ padding:12px 0 10px 10px; border-bottom:1px solid #E0F6FF; color:#333; } 


.es{ width:680px; margin:5px 0 0 55px; float:left; } 
.agreenBox{ width:680px; color:#555; margin:10px 50px 10px; border:1px solid #ddd; padding:10px; height:380px; overflow-y:scroll; border:px solid #efefef; float:left; }
.agreenBox p{ color:#555; } 

.dbedit{ margin:0 80px; padding:20px 0 30px; margin-top:10px; margin-bottom:30px; border-top:1px solid #C5E8F6; background:#fff; float:left;}
.dbedit .name{ width:100%; color:#333; padding:5px 0 5px 220px; font-size:18px; color:#1080B5; font-weight:bold; float:left; }
table.etable tr td{ padding:3px 0; }
table.etable tr td:first-child{ text-align:right; color:#888; padding-right:10px; }
table.etable tr td span{ padding:6px 0 0 10px; color:#666666; float:left; }
table.etable tr td input{ padding:8px; float:left; } 

.endbox{ width:620px; margin:10px 60px 50px; padding:20px 30px; border:px solid #efefef; background:#fff; float:left; }
.endbox .h3{ width:100%; font-size:22px; float:left; }
.endbox .h4{ width:100%; padding:10px 0; color:#666; float:left; }
.endbox .shpx{ width:100%; padding:10px 0; float:left; }
.endbox .shpx a{ border:1px solid #FF9900; background:#FF9900; color:#fff; text-decoration:none; border-radius:1px; padding:10px 20px; margin-right:20px; float:left; }

.next{ width:100%; text-align:center; margin:10px 0 20px; float:left; }
input.submit{ padding:10px 20px; background:#0A9FE5; color:#fff; margin-bottom:10px; font-size:14px; border-radius:1px; float:none; }
input.submit:disabled{ background:#ddd; }

span.error{ color:#f00; font-weight:bold; } 

/*协议*/
.ament{ background:#fff; border:1px solid #eee; margin-top:30px; margin-bottom:20px; float:left; }
.ament p{ color:#888; line-height:22px; }
.ament strong{ color:#333; } 
</style>
</head>
<body>
<div class="main_bar">
	<span><a href="<?php echo $uq3;?>"><img src="./admin/templates/public/images/admin_logo.png"/></a></span>
</div>
<div class="main">
<div class="maincon">
	<div class="head"> 
		<div class="lname">系统安装</div> 
		<div class="rhelp">
			<a href="http://www.uqcms.com/article/show?alias=jiaocheng" target="_blank">
				<i>?</i>安装帮助
			</a>
		</div>
	</div>
<?php
 if($uq0 >= '2'){ ?>
		<div class="navigation">
			<span <?php if($uq0 >= '2'){ echo 'class="ch"';} ?>><i>√</i><em>环境检测</em></span>
			<span <?php if($uq0 >= '3'){ echo 'class="ch"';} ?>><i>√</i><em>配置参数</em></span>
			<span <?php if($uq0 >= '4'){ echo 'class="ch"';} ?>><i>√</i><em>安装执行</em></span>
			<span <?php if($uq0 >= '5'){ echo 'class="ch"';} ?>><i>√</i><em>安装完成</em></span>
		</div> 
<?php  } if($uq0 == '2'){ $uq6 = 0; ?> 
	<form action="install.php?step=3" method="post">
		<div class="es">
			<table class="ltable">
				<thead>
					<tr>
						<th width="180">项目</th>
						<th width="180">当前配置</th>
						<th width="150">参考配置</th>
						<th>支持功能</th> 
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>操作系统</td>
						<td><?php echo PHP_OS; ?></td>
						<td>不限制</td>
						<td>推荐Linux</td>
					</tr>
					<tr>
						<td>服务器环境</td>
						<td><?php echo $_SERVER["SERVER_SOFTWARE"]; ?></td>
						<td>apache2.0/nginx1.6以上</td>
						<td>推荐nginx</td>
					</tr>
					<tr>
						<td>PHP版本</td>
						<td><?php  if(version_compare(PHP_VERSION, '7.0.0')>=0){ echo @phpversion(); }else{ echo '<span class="error">版本过低</span>'; $uq6++; } ?></td>
						<td>7.0.0以上</td>
						<td>运行条件</td>
					</tr>
					<tr>
						<td>附件上传</td>
						<td><?php  echo ini_get('max_execution_time'); ?>M</td>
						<td>不低于2M</td>
						<td>上传本地文件</td>
					</tr>
					<tr>
						<td>GD库</td>
						<td><?php  if(function_exists('imagecreate')){ $uq7 = gd_info(); echo $uq7['GD Version']; }else{ echo '<span class="error">未启用</span>'; $uq6++; } ?></td>
						<td>1.0</td>
						<td>图形验证码</td>
					</tr>
					<tr>
						<td>mysqli</td>
						<td><?php if(function_exists('mysqli_connect')){ echo '支持'; }else{ echo '<span class="error">未启用</span>'; $uq6++; } ?></td>
						<td>启用</td>
						<td>数据储存</td>
					</tr> 
				</tbody> 
			</table> 
			<table class="ltable" width="100%">
				<thead>
					<tr>
						<th width="180">目录文件</th> 
						<th width="180">写入权限</th> 
						<th width="150">读取权限</th> 
						<th>权限要求</th> 
					</tr>
				</thead>
				<tbody>
				<?php  $uq8 = ['data', 'temp']; foreach($uq8 as $uq9){ ?>
					<tr>
						<td><?php echo $uq9; ?></td>
						<td>
							<?php  if(is_writable($uq9)){ echo '&radic;可写' ; }else{ echo '<span class="error">&radic;不可写</span>'; $uq6++; } ?>
						</td>
						<td>
							<?php  if(is_readable($uq9)){ echo '&radic;可读' ; }else{ echo '<span class="error">&radic;不可读</span>'; $uq6++; } ?>
						</td> 
						<td>&radic;可读&radic;可写</td> 
					 </tr>
				<?php } ?>
				</tbody> 
			</table>
		</div>
		<div class="next">
			<input type="submit" name="agreen" class="submit" <?php if($uq6 >= '1'){ echo 'disabled="disabled"'; } ?> value="下一步"/> 
		</div>
<?php }elseif($uq0 == '3'){ ?>
		<div class="dbedit">
			<form action="install.php?step=4" method="post">
				<div class="name">数据库配置</div>
				<table class="etable" width="100%"> 
					<tr><td width="210">地址：</td><td><input type="text" size="32" name="db_host" id="host" value="127.0.0.1"/></td></tr> 
					<tr><td>用户名：</td><td><input type="text" size="32" name="db_user" id="user" value="root"/></td></tr>
					<tr><td>密码：</td><td><input type="text" size="32" name="db_pass" id="pass" value=""/></td></tr>
					<tr><td>数据库：</td><td><input type="text" size="32" name="db_name" id="name" value=""/></td></tr> 
					<tr><td>端口：</td><td><input type="text" size="32" name="port" id="port" value="3306"/><span>默认3306</span></td></tr>
					<tr><td>&nbsp;</td><td>
						<label><input name="demo_data" type="checkbox" value="1"><span style="padding:5px 0 0 5px;">安装测试数据</span></label>
					</td></tr>  
				</table> 
				<div class="name">管理员设置</div>
				<table class="etable">
					<tr><td width="210">登录账号：</td><td><input type="text" size="32" name="admin" id="admin_user" value="admin"/></td></tr>
					<tr><td>新密码：</td><td><input type="text" size="32" name="admin_pass" id="admin_pass" value=""/></td></tr>
					<tr><td>确认密码：</td><td><input type="text" size="32" name="admin_repass" id="admin_pass2" value=""/></td></tr>
				</table>
				<div class="next">
					<input type="submit" name="install" class="submit" value="提交安装"/>
				</div>
			</form>
		</div>
<script type="text/javascript">
	$("form").submit(function(){
		var host = $('#host').val();
		if(host == ''){ 
			alert('数据库地址不能为空'); return false; 
		}
		var user = $('#user').val();
		if(user == ''){ 
			alert('用户名不能为空');  return false;
		}
		var pass = $('#pass').val();
		if(pass == ''){ 
			alert('连接密码地址不能为空'); return false;
		}
		var name = $('#name').val();
		if(name == ''){ 
			alert('数据库名称不能为空'); return false;
		}
		if($('#admin_user').val() == ''){ 
			alert('管理员账户不能为空'); return false;
		}
		var admin_pass = $('#admin_pass').val();
		var admin_pass2 = $('#admin_pass2').val();
		if(admin_pass == ''){ 
			alert('管理员密码不能为空'); return false;
		}
		if(admin_pass2 == ''){ 
			alert('管理员重复密码不能为空'); return false;
		}
		if(admin_pass != admin_pass2){
			alert('管理员两次密码输入不一致'); return false;
		}
	});
</script>
<?php }elseif($uq0 == '4'){ ?>
		<div class="agreenBox" style="margin-bottom:30px;" id="installing">&nbsp;</div> 
<?php }elseif($uq0 == '5'){ ?>
		<div class="endbox">
			<div class="h3">恭喜你！安装完成，进入后台管理</div>
			<div class="h4">为了您站点的安全，安装完成后请删除install.php文件，防止重复安装。</div>
			<div class="shpx">
				<span><a href="<?php echo $uq3; ?>">网站首页</a></span>
				<span><a href="<?php echo $uq3; ?>/index.php/admin/index/index">后台管理</a></span>
			</div>	
		</div>
<?php }else{ ?> 
		<form action="install.php?step=2" method="post"> 
			<div class="agreenBox ament">
				<h2>公共版授权协议，适用于全部UQCMS云商用户</h2> 
				UQCMS云商 的官方网址是： <a href="http://www.uqcms.com" target="_blank">www.uqcms.com</a>  <br />
				为了使你正确并合法的使用本软件，请你在使用前务必阅读清楚下面的协议条款：<br />
				<strong>一、本授权协议适用且仅适用于UQCMS云商公版系统，UQCMS云商官方对本授权协议的最终解释权。</strong><br />
				<strong>二、协议许可的权利</strong> <br />
				1、您可以在完全遵守本最终用户授权协议的基础上，将本软件应用于商业用途。 <br />
				2、您可以在协议规定的约束和限制范围内修改 UQCMS源代码或界面风格以适应您的网站要求。 <br />
				3、您拥有使用本软件构建的网站全部内容所有权，并独立承担与这些内容的相关法律义务。<br />		  4、获得商业授权之后，您可以将本软件应用于商业用途，同时依据所购买的授权类型中确定的技术支持内容，自购买时刻起，在技术支持期限内拥有通过指定的方式获得指定范围内的技术支持服务。商业授权用户享有反映和提出意见的权力，相关意见将被作为首要考虑，但没有一定被采纳的承诺或保证。 <br />	
				<strong>三、协议规定的约束和限制</strong> <br />		    
				1、未获商业授权之前，不得将本软件用于任何用途。购买商业授权请登录 www.uqcms.com 了解最新说明。<br />	
				2、未经官方许可，不得对本软件或与之关联的商业授权进行出租、出售、抵押或发放子许可证。<br />	
				3、不管你的网站是否整体使用 UQCMS ，还是部份栏目使用UQCMS，在你使用了UQCMS的网站主页上必须加上UQCMS官方网址(www.UQCMS.com)的链接。<br />	
				4、未经官方许可，禁止在UQCMS云商的整体或任何部分基础上以发展任何派生版本、修改版本或第三方版本用于重新分发。<br />	
				5、如果您未能遵守本协议的条款，您的授权将被终止，所被许可的权利将被收回，并承担相应法律责任。 <br />	
				<strong>四、有限担保和免责声明</strong> <br />
				1、本软件及所附带的文件是作为不提供任何明确的或隐含的赔偿或担保的形式提供的。 	<br />		  
				2、用户出于自愿而使用本软件，您必须了解使用本软件的风险，在尚未购买产品技术服务之前，我们不承诺对免费用户提供任何形式的技术支持、使用担保，也不承担任何因使用本软件而产生问题的相关责任。 <br />	
				3、电子文本形式的授权协议如同双方书面签署的协议一样，具有完全的和等同的法律效力。您一旦开始确认本协议并安装UQCMS，即被视为完全理解并接受本协议的各项条款，在享有上述条款授予的权力的同时，受到相关的约束和限制。协议许可范围以外的行为，将直接违反本授权协议并构成侵权，我们有权随时终止授权，责令停止损害，并保留追究相关责任的权力。<br />	
				4、如果本软件带有其它软件的整合API示范例子包，这些文件版权不属于本软件官方，并且这些文件是没经过授权发布的，请参考相关软件的使用许可合法的使用。<br />	
				协议发布时间： 2019年7月20日	<br />
				</p>
			</div>
			<div class="next">
				<input type="submit" name="agreen" class="submit" value="同意并开始安装"/>
			</div>
		</form> 
<?php  } ?> 
</div>
</div>
</body>
</html>
<script type="text/javascript">
function updateProgress(id){
	$('#installing').append('<p>'+id+'</p>');
	var div = document.getElementById('installing');
	div.scrollTop = div.scrollHeight;
}
$(function(){
	$('.agreenBox').niceScroll({
		cursorcolor: "#ccc",
		cursoropacitymax: 1,
		touchbehavior: false, 
		cursorwidth: "5px", 
		cursorborder: "0", 
		cursorborderradius: "5px", 
		autohidemode: false, 
		horizrailenabled: false,
		hidecursordelay: 10, 
		boxzoom:true
	}); 
}); 
</script> 
<?php
function randstr($uq10=6) { $uq11=''; $uq12= 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz@#!~?:-='; $uq13=strlen($uq12)-1; mt_srand((double)microtime()*1000000); for($uq14=0;$uq14<$uq10;$uq14++) { $uq11.=$uq12[mt_rand(0,$uq13)]; } return $uq11; } function error_msg_install($uq15){ echo "<script type=\"text/javascript\">updateProgress('".$uq15."');</script>"; exit; } if(isset($_POST['install'])) { set_time_limit(0); $uq16 = ini_get('output_buffering'); $uq17 = ''; $uq17 .= str_repeat(" ", $uq16); ob_flush(); flush(); $uq18 = !empty($_POST['db_host'])?trim($_POST['db_host']):error_msg_install('数据库地址不能为空'); $uq19 = !empty($_POST['db_user'])?trim($_POST['db_user']):error_msg_install('数据库用户名不能为空'); $uq20 = !empty($_POST['db_pass'])?trim($_POST['db_pass']):error_msg_install('数据库密码不能为空'); $uq21 = !empty($_POST['db_name'])?trim($_POST['db_name']):error_msg_install('数据库不能为空'); $uq22 = !empty($_POST['db_port'])?trim($_POST['db_port']):3306; $uq23 = !empty($_POST['demo_data'])?1:0; $uq24 = 'uq_'; $uq25 = './data/sql/install.sql'; $uq26 = @mysqli_connect($uq18, $uq19, $uq20); if(!$uq26){ error_msg_install('<h3>连接数据库错误，请核对信息是否正确</h3>'); } if(mysqli_get_server_info($uq26) < 5.5){ error_msg_install ("安装失败，数据库版本太低，请使用MySql5.5以上版本。需要支持Innodb。"); } if(!mysqli_select_db($uq26, $uq21)){ if(!mysqli_query($uq26, "CREATE DATABASE IF NOT EXISTS `".$uq21."` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci")){ error_msg_install('数据库不存在，也无权限创建数据库。'); } mysqli_select_db($uq26, $uq21); } mysqli_query($uq26, "SET names UTF8"); $uq27 = mysqli_query($uq26, "show engines;"); while($uq28 = mysqli_fetch_array($uq27)){ if((($uq28['Engine'] == 'InnoDB') && ($uq28['Support'] == 'DEFAULT')) || (($uq28['Engine'] == 'InnoDB') && ($uq28['Support'] == 'YES')) ) { $uq29 = true; } } if(!isset($uq29)){ error_msg_install('数据库不支持innodb，请调试MySqL支持innodb再安装。 '); } $uq30 = mysqli_query($uq26, "SHOW TABLES FROM ".$uq21); while($uq31 = mysqli_fetch_row($uq30)){ $uq32[] = $uq31; } if(isset($uq32)){ if(count($uq32) > 0){ error_msg_install('数据库不是空数据库。请清空或者修改数据库重新提交安装。'); } } $uq33 = 'data/sql/sql_install.sql'; $uq34 = file_get_contents($uq33); preg_match_all('/CREATE(.*);/iUs', $uq34, $uq35); foreach($uq35[0] as $uq36){ $uq37 = str_replace('\n\r','',$uq36); $uq38 = mysqli_query($uq26, $uq37); if($uq38){ preg_match('/CREATE TABLE `([^ ]*)`/', $uq37, $uq39); $uq40 = str_replace($uq24, '', $uq39[1]) ; echo $uq17."<script type=\"text/javascript\">updateProgress('创建表：".$uq40." ... 成功');</script>"; ob_flush(); flush(); }else{ file_put_contents('data/sql/install_error.sql', $uq37, FILE_APPEND); } } $uq41 = array( 'mysql'=>array( 'DB_HOST'=>$uq18, 'DB_USER'=>$uq19, 'DB_PWD'=>$uq20, 'DB_NAME'=>$uq21, 'DB_PRE'=>$uq24 ) ); $uq42 = "<?php \n return ".var_export($uq41, TRUE).";\n ?>"; file_put_contents($uq4, $uq42); echo $uq17."<script type=\"text/javascript\">updateProgress('创建数据库连接文件 ... 成功');</script>"; ob_flush(); flush(); if($uq23 == 1){ $uq43 = 'data/sql/sql_demo.sql'; }else{ $uq43 = 'data/sql/sql_config.sql'; } $uq43 = file_get_contents($uq43); preg_match_all('/INSERT(.*)(?:\));/iUs', $uq43, $array2); foreach($array2[0] as $uq36){ $uq37 = str_replace('\n\r','',$uq36); $uq38 = mysqli_query($uq26, $uq37); if($uq38){ echo $uq17."<script type=\"text/javascript\">updateProgress('导入配置文件 ... 成功');</script>"; ob_flush(); flush(); }else{ file_put_contents('data/sql/install_error.sql', $uq37, FILE_APPEND); } } $uq44 = isset($_POST['admin'])?trim($_POST['admin']):error_msg('管理员用户名不能为空'); $uq45 = isset($_POST['admin_pass'])?$_POST['admin_pass']:error_msg('管理员密码不能为空'); $uq46 = randstr(12); $uq47 = '<?'."php\n"; $uq47 .= "return '{$uq46}'; "; $uq48 = @fopen($uq5, 'wb+'); if(!$uq48){ error_msg('打开文件失败,请确保data目录可读。'); } if(!@fwrite($uq48, trim($uq47))){ error_msg('写入文件失败，请确保data目录可写'); } @fclose($uq48); $uq49 = substr(md5($uq45), 5, 10); $uq50 = md5(md5($uq45).$uq49.$uq46); $uq51 = mysqli_query($uq26, "INSERT INTO `uq_admin` (`aid`, `type`, `username`, `password`, `email`, `mobile`, `power`, `rank`, `status`, `addtime`) VALUES (1, '1', '".$uq44."', '".$uq50."', NULL, NULL, '0', '0', '1', '".time()."');"); if($uq51){ echo $uq17."<script type=\"text/javascript\">updateProgress('管理员账号创建成功 ... 成功');</script>"; ob_flush(); flush(); } file_put_contents('data/install.lock', '1'); mysqli_query($uq26, "delete from `uq_config` where `name` = 'storage_alias'"); if($uq23 == 1){ mysqli_query($uq26, "INSERT INTO `uq_config` (`name`, `value`) VALUES ('storage_alias', 'demo');"); }else{ mysqli_query($uq26, "INSERT INTO `uq_config` (`name`, `value`) VALUES ('storage_alias', 'local');"); } echo $uq17."<script type=\"text/javascript\">updateProgress('安装结束,正在跳转...');</script>"; ob_flush(); flush(); sleep(2); echo "<script type=\"text/javascript\"> window.location.href='install.php?step=5'; </script>"; } ?>

