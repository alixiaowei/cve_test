<?php
/** 
 * UQ云商：	www.uqcms.com  
 * 联系QQ：	2200631718 
 * 可免费商用，需要留UQ云商链接作为交换，只首页底部留取即可，不影响使用。
 */
  defined('IN_UQ') or exit('Access Denied'); class admin extends module { function __construct() { $this->aid = @$_SESSION['admin']['aid']; parent::__construct(); } public function index() { $uq0 = $_GET['m']??'index'; $uq1 = $_GET['a']??'index'; $this->v = $_GET['v']??false; if($this->aid != '1'){ if($uq0 != 'index'){ $uq2 = @$_SESSION['admin']['power_con']; if(!empty($uq2)){ $uq3 = explode('@', $uq2); if(isset($uq3)){ foreach($uq3 as $uq4){ $uq5 = explode(':', $uq4); if(isset($uq5[1])){ $uq6[$uq5[0]] = explode(',', $uq5[1]); } } if(isset($uq6)){ if(isset($uq6[$uq0])){ if(!in_array($uq1, $uq6[$uq0])){ $this->back_error(); } }else{ $this->back_error(); } }else{ $this->back_error(); } }else{ $this->back_error(); } }else{ $this->back_error(); } } } if( ($uq0 == 'index' && $uq1 == 'index') || ($uq0 == 'index' && $uq1 == 'login_submit') || ($uq0 == 'index' && $uq1 == 'vcode') ){ }else{ if(!@$_SESSION['admin']['aid']){ location(ADMIN_URL.'/index/index'); } } } private function back_error() { if(empty($this->aid)){ $uq2 = '请重新登录'; }else{ $uq2 = '没有权限操作'; } if($this->v){ error_json($uq2); }else{ $uq7 = '
				<style>
				h1{ width:100%; height:100%; font-size:16px; vertical-align: middle;  }
				h1 i{ width:20px; height:20px; background:#FF0000;   }
				h1 span{ color:#f00; font-family:Microsoft Yahei;  }
				</style>
				<h1><span>'.$uq2.'</span></h1>
				<script>
					if(window.top == window.self){
						 location.href="'.cfg('site_url').ADMIN_URL.'/index/index";
					}else{
						parent.location.reload(); 
					} 	 
				</script>
			'; exit($uq7); } } public function admin_auth() { if(!@$_SESSION['admin']['aid']){ location(ADMIN_URL.'/index/index'); } } } 