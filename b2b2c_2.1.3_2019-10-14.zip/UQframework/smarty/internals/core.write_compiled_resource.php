<?php 
/**
 *	写入编译内容
 */
function smarty_core_write_compiled_resource($params, &$smarty)
{ 
	// echo $smarty->compile_dir; 			// 编译的目录
	
	if(!@is_dir($smarty->compile_dir)) { 	// 是否存在目录  
		$q = mkdir($smarty->compile_dir, 0777, true);		 // realpath($path)		实际的地址
		if(!$q){
			$msg = '模板：目录无法创建';
			// $smarty->trigger_error('编译目录 \'' . $smarty->compile_dir . '\' 不存在, 请手动创建编译目录.', E_USER_ERROR); 
			error_404($msg);
		}
	}
	// realpath($smarty->compile_dir)  实际目录
    if(!@is_writable($smarty->compile_dir)) { 	// 检查是否可写  
		$msg = '模板：无法写入0777';
		// $smarty->trigger_error($msg, E_USER_ERROR);
		error_404($msg);
    }
    require_once(SMARTY_CORE_DIR . 'core.write_file.php');
	
	$_params = [
		'filename' => $params['compile_path'], 
		'contents' => $params['compiled_content'], 
		'create_dirs' => true
	];
    smarty_core_write_file($_params, $smarty);
    return true;
}
