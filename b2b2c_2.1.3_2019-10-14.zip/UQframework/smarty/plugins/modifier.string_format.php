<?php 
function smarty_modifier_string_format($string, $format)
{
    return sprintf($format, $string);
} 
?>
