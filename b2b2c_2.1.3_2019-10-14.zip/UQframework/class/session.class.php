<?php
/** 
 * UQ云商：	www.uqcms.com  
 * 联系QQ：	2200631718 
 * 可免费商用，需要留UQ云商链接作为交换，只首页底部留取即可，不影响使用。
 */
  defined('IN_UQ') or exit('Access Denied'); class session { public static $uq0 = 'session|sess_'; static function start() { ini_set("session.name", 'UQCMSID'); ini_set('session.gc_maxlifetime', cfg('site_session_time')); ini_set('session.auto_start', '0'); session_set_save_handler( [__CLASS__, 'open'], [__CLASS__, 'close'], [__CLASS__, 'read'], [__CLASS__, 'write'], [__CLASS__, 'destroy'], [__CLASS__, 'gc'] ); session_start(); } public static function open() { return true; } public static function read($uq1) { $uq2 = self::$uq0.$uq1; $uq3 = cache::get($uq2, cfg('site_session_time'), false); if($uq3){ return $uq3; }else{ $uq3 = cache::add($uq2, ' ', false); if($uq3){ return ' '; }else{ return false; } } } public static function write($uq1, $uq4) { $uq2 = self::$uq0.$uq1; $uq3 = cache::add($uq2, $uq4, false); if($uq3){ return true; }else{ return false; } } public static function destroy($uq1) { $uq5 = cache::del(self::$uq0.$uq1); if($uq5){ return true; }else{ return false; } } public static function gc($uq6) { return true; } public static function close() { return true; } } 