<?php
/** 
 * UQ云商：	www.uqcms.com  
 * 联系QQ：	2200631718 
 * 可免费商用，需要留UQ云商链接作为交换，只首页底部留取即可，不影响使用。
 */

defined('IN_UQ') or exit('Access Denied'); class upload { static public function reset_new_name($uq0) { $uq1 = date("y").'/'.date("md").'/'.(date("his",time()).microtime()*1000000).'.'.self::getExt($uq0); return $uq1; } static public function store($uq2, $uq3 = null, $uq4 = null) { if(empty($uq4)){ $uq5 = array(); $uq6 = array_values($_FILES); $uq0 = $uq6[0]['name']; $uq7 = $uq6[0]['type']; $uq8 = $uq6[0]['size']; $uq9 = $uq6[0]['tmp_name']; }else{ $uq0 = $uq4; $uq7 = mime_content_type($uq4); $uq8 = filesize($uq4); $uq9 = $uq4; } if($uq0){ if(in_array($uq7, ['image/jpeg','image/gif', 'image/png'])){ if($uq8 < cfg('site_upload_size')){ if(empty($uq3)){ $uq3 = $uq2.'/'.self::reset_new_name($uq0); } if(!_is_dir($uq3)){ file::mk_dir($uq3, true); } if(file::remove($uq9, $uq3)){ $uq5['error'] = '0'; $uq5['name'] = $uq3; $uq5['url'] = cfg('site_path').$uq3; $uq5['size'] = filesize($uq3); return $uq5; }else{ return ['error'=>'1', 'msg'=>'上传错误']; } }else{ return ['error'=>'1', 'msg'=>'上传文件过大,当前图片'.formatBytes($uq8)]; } }else{ return ['error'=>'1', 'msg'=>'不支持此类型的文件,支持：jpg,gif,png']; } }else{ return ['error'=>'1', 'msg'=>'上传的文件不能为空']; } } static public function getExt($uq10){ $uq10 = pathinfo($uq10); return strtolower($uq10['extension']); } } 