<?php
/** 
 * UQ云商：	www.uqcms.com  
 * 联系QQ：	2200631718 
 * 可免费商用，需要留UQ云商链接作为交换，只首页底部留取即可，不影响使用。
 */

 class file_cache { function __construct(){ $this->path = 'cache_dir/'; $this->cache_time = '1800'; } function get($uq0){ $uq1 = $this->file_path($uq0); $uq2 = @file_get_contents($uq1); if($uq2){ return $uq2; }else{ return false; } } function set($uq0,$uq3){ $uq1 = $this->file_path($uq0); $uq4 = $this->write_contents($uq1,$uq3); if($uq4){ return true; }else{ return false; } } function delete($uq0){ $uq1 = $this->file_path($uq0); @unlink($uq1); return true; } function file_path($uq0){ $uq5 = md5($uq0); $uq6 = ''; for($uq7=1;$uq7<3;$uq7++){ $uq6 .= substr($uq5,($uq7*2),2).'/'; } return $this->path.$uq6.$uq5; } function write_contents($uq1,$uq3){ $uq8 = fopen($uq1,'w'); $uq4 = fwrite($uq8,$uq3); fclose($uq8); if($uq4){ return true; }else{ return false; } } }