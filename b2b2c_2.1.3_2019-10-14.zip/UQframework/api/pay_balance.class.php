<?php
/** 
 * UQ云商：	www.uqcms.com  
 * 联系QQ：	2200631718 
 * 可免费商用，需要留UQ云商链接作为交换，只首页底部留取即可，不影响使用。
 */

 class pay_balance { private static $uq0; public static function init() { if (is_null(self::$uq0)){ self::$uq0 = new self(); } return self::$uq0; } function __construct($uq1 = []) { } function pay($uq2) { $uq3 = $uq2['trade_no']; $uq4['type'] = 'link'; $uq4['link'] = cfg['site_domain'].'notice/balance_pay?trade_no='.$uq3; return $uq4; } } 