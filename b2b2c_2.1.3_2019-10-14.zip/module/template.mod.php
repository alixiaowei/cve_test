<?php
/** 
 * UQ云商：	www.uqcms.com  
 * 联系QQ：	2200631718 
 * 可免费商用，需要留UQ云商链接作为交换，只首页底部留取即可，不影响使用。
 */

defined('IN_UQ') or exit('Access Denied'); class template_mod extends module { function theme($uq0) { $uq1 = $uq0['id']??false; $uq2 = $this->db->get_one("select * from ".table('theme')." where id = ".$uq1); return $uq2; } function nav($uq0) { $uq3 = $uq0['limit']?$uq0['limit']:'8'; $uq2 = $this->db->get_all("select * from ".table('navigate')." where status = 1 order by px desc limit ".$uq3); return $uq2; } }