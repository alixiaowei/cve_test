<?php
/** 
 * UQ云商：	www.uqcms.com  
 * 联系QQ：	2200631718 
 * 可免费商用，需要留UQ云商链接作为交换，只首页底部留取即可，不影响使用。
 */

defined('IN_UQ') or exit('Access Denied'); class ad_mod extends module { public function alias($uq0) { $uq1 = $uq0['alias']; $uq2 = $uq0['page_size']??'0'; $uq3 = $this->db->get_one("select * from ".table('ad_postion')." where alias = '".$uq1."' limit 1"); if(isset($uq3['id'])){ if($uq2 != '0'){ $uq4 = ' limit '.$uq2; }else{ $uq4 = ''; } $uq5 = $this->db->get_all("select * from ".table('ad')." where postion = ".$uq3['id']." and start_time < ".time()." and end_time > ".time()." and status = 1 order by addtime desc ".$uq4); if($uq5){ foreach($uq5 as $uq6){ $uq7[] = $uq6; } return $uq7; }else{ return false; } } } public function link() { return $this->db->get_all("select * from ".table('link')); } } 