<?php
/** 
 * UQ云商：	www.uqcms.com  
 * 联系QQ：	2200631718 
 * 可免费商用，需要留UQ云商链接作为交换，只首页底部留取即可，不影响使用。
 */

defined('IN_UQ') or exit('Access Denied'); class wchat_mod extends module { function __construct() { parent::__construct(); } function js_config() { $uq0 = wchat::init()->js_config(); return $uq0; } } 