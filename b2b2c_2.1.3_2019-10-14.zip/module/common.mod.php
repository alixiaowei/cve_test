<?php
/** 
 * UQ云商：	www.uqcms.com  
 * 联系QQ：	2200631718 
 * 可免费商用，需要留UQ云商链接作为交换，只首页底部留取即可，不影响使用。
 */

defined('IN_UQ') or exit('Access Denied'); class common_mod extends module { function __construct() { parent::__construct(); } function yqlink() { $uq0 = $this->db->get_all("select * from ".table('link')." where status = 1 order by px desc"); if($uq0){ foreach($uq0 as $uq1){ $uq2[] = $uq1; } return $uq2; }else{ return false; } } function category($uq3) { $uq4 = $uq3['name']??''; $uq5 = $uq3['canshu']??''; if($uq4){ $uq2 = cache::get("config/category_com_".$uq4); if(!empty($uq2)){ return $uq2; } $uq6 = $this->db->get_one("select * from ".table('category_com')." where alias = '".$uq4."' and status = 1"); if($uq6['id']){ $uq7 = $this->db->get_all("select id,pid,name,alias,link,px,status from ".table('category_com')." where pid = '".$uq6['id']."' and status = 1 order by px desc"); if($uq7){ foreach($uq7 as $uq8=>$uq1){ if(!empty($uq1['alias'])){ if($uq5 == 'all'){ $uq2[$uq1['alias']] = $uq1; }else{ $uq2[$uq1['alias']] = $uq1['name']; } }else{ if($uq5 == 'all'){ $uq2[$uq1['id']] = $uq1; }else{ $uq2[$uq1['id']] = $uq1['name']; } } } cache::add("config/category_com_".$uq4, $uq2); return $uq2; } }else{ return false; } }else{ return false; } } } 