<?php
/** 
 * UQ云商：	www.uqcms.com  
 * 联系QQ：	2200631718 
 * 可免费商用，需要留UQ云商链接作为交换，只首页底部留取即可，不影响使用。
 */
  class seller extends module { function __construct() { $this->uid = @$_SESSION['user']['uid']; $this->spid = @$_SESSION['shop']['id']; parent::__construct(); } function index() { if(!empty($this->uid)){ if(empty($this->spid)){ $uq0 = $this->db->get_one("select * from ".table("shop")." where uid = ".$this->uid); if($uq0['id']){ if($uq0['status'] == '0'){ error_404('店铺关闭，请联系管理员'); }else{ $this->module('shop')->create_session($uq0); } }else{ location('user/reg_shop'); } } }else{ $uq1 = cfg('request_url'); location('member/login?returnUrl='.$uq1); } } } 