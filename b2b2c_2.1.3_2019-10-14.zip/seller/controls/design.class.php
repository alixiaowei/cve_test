<?php
/** 
 * UQ云商：	www.uqcms.com  
 * 联系QQ：	2200631718 
 * 可免费商用，需要留UQ云商链接作为交换，只首页底部留取即可，不影响使用。
 */

defined('IN_UQ') or exit('Access Denied'); class design_uqcms extends control { function __construct(){ $this->spid = $_SESSION['shop']['id']; parent::__construct(); } public function index() { $uq0 = $this->db->get_one("select * from ".table('shop_design')." where shop_id = ".$this->spid); if($uq0['id']){ $this->assign('row', $uq0); }else{ $this->db->add(table('shop_design'), ['shop_id'=>$this->spid]); } $this->display(); } function save() { if($_POST){ $uq1['top_images'] = P('top_images'); $uq1['bg_images'] = P('bg_images'); $uq2 = $this->db->update(table('shop_design'), $uq1, 'shop_id = '.$this->spid); if($uq2){ right_json(); }else{ error_json('保存失败'); } }else{ error_json('提交错误'); } } } 